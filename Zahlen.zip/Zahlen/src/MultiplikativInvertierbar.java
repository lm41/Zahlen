public interface MultiplikativInvertierbar {
    public MultiplikativInvertierbar multiplikativesInverses();
    public boolean istInvertierbar();
}
