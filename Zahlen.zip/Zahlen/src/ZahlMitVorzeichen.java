public interface ZahlMitVorzeichen {
    public boolean nichtNegativ();
}
