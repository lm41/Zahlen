public interface AdditivInvertierbar {
    public AdditivInvertierbar additivesInverses();
}
